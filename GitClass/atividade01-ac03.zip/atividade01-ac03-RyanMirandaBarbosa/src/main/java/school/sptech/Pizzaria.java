package school.sptech;

import java.util.List;

public class Pizzaria {
    private String nome;
    private String telefone;
    private List<Pedido> pedidos;

    public Pizzaria(){
    }

    public Pizzaria(String nome, String telefone, List<Pedido> pedidos) {
        this.nome = nome;
        this.telefone = telefone;
        this.pedidos = pedidos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void setPedidos(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }

    public void adicionarPedido(Pedido pedido) {
        this.pedidos.add(pedido);
    }

    // Retorna a quantidade de pedidos realizados na pizzaria segundo o status informado
    public int qtdPedidos(Status status) {
        int count = 0;
        for (Pedido pedido : pedidos) {
            if (pedido.getStatus().equals(status)) {
                count++;
            }
        }
        return count;
    }

    // Retorna a quantidade de pedidos de delivery realizados na pizzaria
    public int qtdPedidosDelivery() {
        int count = 0;
        for (Pedido pedido : pedidos) {
            if (pedido instanceof PedidoDelivery) {
                count++;
            }
        }
        return count;
    }

    // Retorna a quantidade total de unidades vendidas do sabor informado
    public int qtdUnidadesVendidas(Sabor sabor) {
        int count = 0;
        for (Pedido pedido : pedidos) {
            for (ItemPedido item : pedido.getItens()) {
                if (item.getSabor().equals(sabor)) {
                    count += item.getQuantidade();
                }
            }
        }
        return count;
    }

    // Retorna o faturamento total da pizzaria considerando apenas os pedidos concluídos
    public double calcularFaturamento() {
        double faturamento = 0;
        for (Pedido pedido : pedidos) {
            if (pedido.getStatus() == Status.CONCLUIDO) {
                faturamento += pedido.calcularTotal();
            }
        }
        return faturamento;
    }
}