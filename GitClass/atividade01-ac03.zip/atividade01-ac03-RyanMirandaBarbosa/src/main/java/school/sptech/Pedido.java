package school.sptech;
import java.util.List;
public abstract class Pedido {
    protected String cliente;
    protected Status status;
    protected List<ItemPedido> itens;

    public Pedido(){
    }

    public Pedido(String cliente, Status status, List<ItemPedido> itens) {
        this.cliente = cliente;
        this.status = status;
        this.itens = itens;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }

    public void setItens(List<ItemPedido> itens) {
        this.itens = itens;
    }

    public void setItensPedidos(List<ItemPedido> itensPedidos) {
        this.itens = itensPedidos;
    }

    public abstract Double calcularTotal();

    public void adicionarItem(Sabor sabor, Integer quantidade){
        ItemPedido itemPedido = new ItemPedido(sabor, quantidade);
        itens.add(itemPedido);
    }
}