package school.sptech;

import java.util.List;

public class PedidoRestaurante extends Pedido{
    private Double gorjeta;
    private Boolean mesaEspecial;

    public PedidoRestaurante(){
    }
    public PedidoRestaurante(String cliente, Status status, List<ItemPedido> itensPedidos, Double grojeta, Boolean mesaEspecial) {
        super(cliente, status, itensPedidos);
        this.gorjeta = grojeta;
        this.mesaEspecial = mesaEspecial;
    }

    public Double getGorjeta() {
        return gorjeta;
    }

    public Boolean getMesaEspecial() {
        return mesaEspecial;
    }

    public void setGorjeta(Double gorjeta) {
        this.gorjeta = gorjeta;
    }

    public void setMesaEspecial(Boolean mesaEspecial) {
        this.mesaEspecial = mesaEspecial;
    }

    @Override
    public Double calcularTotal() {
        Double total = gorjeta;

        if (mesaEspecial){
            total += 20.0;
        }

        for (ItemPedido itemPedidoDaVez : itens) {
           total += itemPedidoDaVez.calcularSubtotal();
        }

        return total;
    }
}