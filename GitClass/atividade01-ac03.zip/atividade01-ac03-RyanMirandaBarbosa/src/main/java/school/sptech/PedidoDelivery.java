package school.sptech;

import java.util.List;

public class PedidoDelivery extends Pedido{
    private Double distanciaKm;

    public PedidoDelivery(){
    }

    public PedidoDelivery(String cliente, Status status, List<ItemPedido> itens, Double distanciaKm) {
        super(cliente, status, itens);
        this.distanciaKm = distanciaKm;
    }

    public Double getDistanciaKm() {
        return distanciaKm;
    }

    public void setDistanciaKm(Double distanciaKm) {
        this.distanciaKm = distanciaKm;
    }
    
    @Override
    public Double calcularTotal() {
        Double total = 0.0;
        Double calculoFrete = calcularFrete();
        total += calculoFrete;

        for (ItemPedido itemPedidoDaVez : itens) {
            total += itemPedidoDaVez.calcularSubtotal();
        }

        return total;
    }
    
    public Double calcularFrete(){
        Double valorFrete;
        if (distanciaKm < 5.0){
            valorFrete = 5.0;
        } else if (distanciaKm >= 5.0 && distanciaKm < 10.0){
            valorFrete = 7.0;
        } else {
            valorFrete = 10.0;
        }
        
        return valorFrete;
    }
}