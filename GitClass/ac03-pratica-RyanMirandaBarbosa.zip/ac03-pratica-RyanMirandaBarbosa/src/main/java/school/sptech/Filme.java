package school.sptech;

public class Filme extends Midia{
    private String diretor;
    private Integer duracao;
    private Integer duracaoCreditos;

    public Filme(){
    }

    public Filme(String nome, Double nota, Integer classificacaoEtaria, Genero genero, String diretor, Integer duracao, Integer duracaoCreditos) {
        super(nome, nota, classificacaoEtaria, genero);
        this.diretor = diretor;
        this.duracao = duracao;
        this.duracaoCreditos = duracaoCreditos;
    }

    public String getDiretor() {
        return diretor;
    }

    public void setDiretor(String diretor) {
        this.diretor = diretor;
    }

    public Integer getDuracao() {
        return duracao;
    }

    public void setDuracao(Integer duracao) {
        this.duracao = duracao;
    }

    public Integer getDuracaoCreditos() {
        return duracaoCreditos;
    }

    public void setDuracaoCreditos(Integer duracaoCreditos) {
        this.duracaoCreditos = duracaoCreditos;
    }

    @Override
    public Integer calcularDuracaoTotal() {
        return this.duracao + this.duracaoCreditos;
    }
}