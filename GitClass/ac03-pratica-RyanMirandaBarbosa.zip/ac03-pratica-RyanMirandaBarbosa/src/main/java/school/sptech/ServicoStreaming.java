package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class ServicoStreaming {
    private String nome;
    private List<Midia> midias;

    public ServicoStreaming(){}

    public ServicoStreaming(String nome, List<Midia> midias) {
        this.nome = nome;
        this.midias = midias;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Midia> getMidias() {
        return midias;
    }

    public void setMidias(List<Midia> midias) {
        this.midias = midias;
    }

    public void adicionar(Midia midia){
        midias.add(midia);
    }

    public Integer duracaoTotalPlataforma(){
        Integer duracaoTotal = 0;
        for (int i = 0; i < midias.size(); i++) {
            duracaoTotal += midias.get(i).calcularDuracaoTotal();
        }
        return duracaoTotal;
    }

    public List<Midia> listarPorNotaMaior(Double nota){
        List<Midia> auxList = new ArrayList<>();

        for (int i = 0; i < midias.size(); i++) {
            if (midias.get(i).getNota() > nota){
                auxList.add(midias.get(i));
            }
        }

        return auxList;
    }

    public List<Midia> listarPorGenero(Genero genero){
        List<Midia> auxList = new ArrayList<>();

        for (int i = 0; i < midias.size(); i++) {
            if (midias.get(i).getGenero().equals(genero)){
                auxList.add(midias.get(i));
            }
        }

        return auxList;
    }

    public List<Midia> listarFilmesPorGenero(Genero genero){
        List<Midia> auxList = new ArrayList<>();

        for (Midia midia : midias) {
            if (midia instanceof Filme && midia.getGenero().equals(genero)){
                auxList.add(midia);
            }
        }

        return auxList;
    }
}