package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    private String cliente;
    private List<Produto> produtos;

    public Integer getQuantidade(){
        return produtos.size();
    }

    public void adicionar(Produto p){
        produtos.add(p);
    }

    public Boolean existsPorNome(String nome){
        Boolean nomeEcontrado = false;
        for (Produto produto : produtos){
            if (produto.getNome().toLowerCase().contains(nome.toLowerCase())){
                nomeEcontrado = true;
            }
        }

        return nomeEcontrado;
    }

    public Integer getQuantidadePorCategoria(String nome){
        Integer quanditadeDeProdutoCategoria = 0;
        for (Produto produto : produtos){
            if (produto.getCategoria().contains(nome)){
                quanditadeDeProdutoCategoria++;
            }
        }

        return quanditadeDeProdutoCategoria;
    }

    public void limpar(){
        produtos.clear();
    }

    public void removerPorNome(String nome){
        for (Produto produto : produtos) {
            if (produto.getNome().toLowerCase().contains(nome.toLowerCase())){
                produtos.remove(produto);
                break;
            }
        }
    }

    public Produto getPorNome(String nome) {
        for (Produto produto : produtos) {
            if (produto.getNome().equalsIgnoreCase(nome)) {
                return produto;
            }
        }
        return null; // Retorna null se o produto não for encontrado
    }

    public double getValorTotal() {
        double total = 0.0;
        for (Produto produto : produtos) {
            total += produto.getPreco();
        }
        return total;
    }


    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
    }
}