package school.sptech.sprint1_nota1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint1Nota1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sprint1Nota1Application.class, args);
	}

}
