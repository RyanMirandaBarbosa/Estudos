package school.sptech;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Compra {
    private String nomeCliente;
    private List<Produto> produtos = new ArrayList<>();

    public Compra(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public void adicionarProduto(Produto produto){
        if (produto != null){
            produtos.add(produto);
        }
    }

    public void removerProduto(int indice){
        if (indice >= 0 && indice < produtos.size()){
            produtos.remove(indice);
        }
    }

    public Integer getQuantidadeProdutos(){
        Integer qtdProdutos = produtos.size();
        return qtdProdutos;
    }

    public Integer getQuantidadeProdutosFrageis(){
        Integer qtdFrageis = 0;

        for (Produto produto : produtos){
            if (produto.getFragil().equals(true)){
                qtdFrageis += 1;
            }
        }
        return qtdFrageis;
    }

    public Produto getProdutoPorNome(String nome){
        Produto produtoDaVez = null;

        for (Produto produto : produtos){
            if (produto.getNome().toLowerCase().contains(nome.toLowerCase())){
                produtoDaVez = produto;
            }
        }
        return produtoDaVez;
    }

    public List<Produto> getProdutosPorCategoria(String categoria){
        List<Produto> produtosCategoria = new ArrayList<>();

        for (Produto produto : produtos){
            if (produto.getCategoria().equalsIgnoreCase(categoria)){
                produtosCategoria.add(produto);
            }
        }

        return produtosCategoria;
    }

    public Double calcularTotalFrete(){
        Double totalFrete = 0.0;

        for (int i = 0; i < produtos.size(); i++) {
            Double somandoFrete = produtos.get(i).calcularFrete();
            totalFrete += somandoFrete;
        }

        return totalFrete;
    }

    public Double calcularTotalProdutos(){
        Double totalProdutos = 0.0;

        for (int i = 0; i < produtos.size(); i++) {
            Double somandoProdutos = produtos.get(i).getPreco();
            totalProdutos += somandoProdutos;
        }

        return totalProdutos;
    }

    public Double calcularTotalCompra(){
        Double totalCompra = 0.0;

        Double aux1 = calcularTotalFrete();
        Double aux2 = calcularTotalProdutos();

        totalCompra = aux1 + aux2;

        return totalCompra;
    }
}